BASE
*1
*2